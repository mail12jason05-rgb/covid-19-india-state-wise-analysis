CREATE TABLE covid_statewise (
 Date DATE, State VARCHAR(100), New_Cases INT, Confirmed_Cases INT,
 New_Recovered INT, Recovered_Cases INT, New_Deaths INT, Deaths INT,
 Active_Cases INT, Vaccination_Doses BIGINT, Recovery_Rate DECIMAL(6,2),
 Death_Rate DECIMAL(6,2)
);

SELECT State, MAX(Confirmed_Cases) AS Total_Confirmed
FROM covid_statewise GROUP BY State ORDER BY Total_Confirmed DESC;

SELECT State, MAX(Confirmed_Cases) AS Confirmed,
MAX(Recovered_Cases) AS Recovered,
ROUND(MAX(Recovered_Cases)*100.0/NULLIF(MAX(Confirmed_Cases),0),2) AS Recovery_Rate
FROM covid_statewise GROUP BY State ORDER BY Recovery_Rate DESC;

SELECT State, MAX(Vaccination_Doses) AS Vaccination_Doses
FROM covid_statewise GROUP BY State ORDER BY Vaccination_Doses DESC;
