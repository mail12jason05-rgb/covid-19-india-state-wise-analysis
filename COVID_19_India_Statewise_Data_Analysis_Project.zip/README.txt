COVID-19 INDIA STATE-WISE DATA ANALYSIS

Files:
- covid_india_statewise_50000plus.csv — 50,000+ row practice dataset
- analysis.py — Python/Pandas/Matplotlib analysis
- analysis_queries.sql — SQL analysis queries
- POWER_BI_GUIDE.txt — dashboard instructions

Project flow:
CSV -> Python/Pandas cleaning -> SQL -> Power BI -> Insights

NOTE: The dataset included here is synthetic/realistic practice data because the original dataset from the resume was not attached. Use the actual source data if you have it.
