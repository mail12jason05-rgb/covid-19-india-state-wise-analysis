import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("covid_india_statewise_50000plus.csv")
df["Date"] = pd.to_datetime(df["Date"])

print("Rows:", len(df))
print(df.isna().sum())

summary = df.groupby("State").agg(
    Confirmed=("Confirmed_Cases","max"),
    Recovered=("Recovered_Cases","max"),
    Deaths=("Deaths","max"),
    Vaccination=("Vaccination_Doses","max")
).sort_values("Confirmed", ascending=False)

summary["Recovery_Rate"] = (summary["Recovered"]/summary["Confirmed"]*100).round(2)
print(summary.head(10))

daily = df.groupby("Date")["New_Cases"].sum()
daily.plot(figsize=(12,5), title="India COVID-19 Daily New Cases")
plt.xlabel("Date")
plt.ylabel("New Cases")
plt.tight_layout()
plt.savefig("daily_case_trend.png", dpi=150)
plt.show()
